python scripts/run_tests.py
python scripts/run_tests.py
