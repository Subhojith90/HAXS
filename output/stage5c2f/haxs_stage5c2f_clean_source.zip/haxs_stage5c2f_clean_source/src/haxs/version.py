__version__ = "0.1.0"
ENGINE_NAME = "hole_aware_xxz_squeezing_engine"
