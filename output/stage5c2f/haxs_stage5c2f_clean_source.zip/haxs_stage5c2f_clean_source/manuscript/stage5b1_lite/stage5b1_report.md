# Stage 5B1 Replicated Five-Label Mechanism Decomposition Report

## Decision

- stage: `stage5b1_replicated_five_label_mechanism_decomposition`
- route: `stage5b1_replicated_five_label_needs_more_power_or_repair`
- core_contrast_replicated: `False`
- component_contrasts_replicated: `False`
- block_compatibility_passed: `True`
- local_fixed_time_window_passed: `True`
- stage5b1_passed: `False`
- stage5b_design_review_allowed: `False`
- stage5c_broad_compute_allowed: `False`
- publication_claim_allowed: `False`

## Core replicated contrast

| block       |   mean_fixed_effect_db |   t_ci_low |   t_ci_high |   negative_seed_fraction |   trajectory_fraction_primary_pair | strict_contrast_passed   |
|:------------|-----------------------:|-----------:|------------:|-------------------------:|-----------------------------------:|:-------------------------|
| primary     |              -0.278648 |  -0.385064 |   -0.172231 |                        1 |                           0.579499 | False                    |
| replication |              -0.383199 |  -0.557621 |   -0.208777 |                        1 |                           0.48934  | True                     |

## Interpretation

This is a gated target-shape mechanism preflight. It may justify holdout-geometry design if the strict replicated five-label gates pass. It does not justify broad finite-size scaling or publication claims.

## Claims forbidden

- Publication-grade mechanism proof.
- Broad finite-size scaling.
- Exact quantum mobile-hole dynamics.
- Constructive recovery.
