# HAXS Stage 5C.2F Occupancy-Preserving Re-lock

This package implements the supervisor-ordered Stage 5C.2F software/provenance repair and the preregistered fresh balanced primary re-lock.

The selected design is a completely fresh balanced 16 x 6 x 4 primary block. It does not approve Stage 5C3 production, Stage 5D compute, public release, or publication claims.

## Fresh setup

```bash
python -m pip install -e .
python scripts/run_stage5c2f_all.py --preflight
```

## Frozen confirmation

The package includes the frozen confirmation under `results/stage5c2d_lite/confirmation`. The new primary uses no legacy primary cells.

## Run

```bash
python scripts/run_stage5c2f_fresh_unzip_gate.py
python scripts/run_stage5c2f_all.py
```

## Inspect

```bash
cat results/stage5c2f/preflight/stage5c2f_hierarchy_gate.json
cat results/stage5c2f/analysis/stage5c2f_decision.json
```

## Manifest

```bash
python scripts/make_stage5c2f_manifest.py --root . --out MANIFEST.sha256
python scripts/verify_manifest.py --root . --manifest MANIFEST.sha256
```

## Claim boundary

Allowed: this stage checks whether one preregistered 3x3x3 stochastic-surrogate primary block clears the repaired hierarchy and precision gates.

Forbidden: Stage 5C3 production approval, Stage 5D compute, publication-readiness claims, exact mobile-hole dynamics, component-mechanism claims, or finite-size scaling claims.
