# Environment notes

## Audit environment

- Date: 2026-09-01
- Operating system: Linux-6.18.35-x86_64-with-glibc2.41
- Machine: x86_64
- Python: 3.13.5
- LaTeX: pdfLaTeX through latexmk
- PDF rendering: `/home/oai/skills/pdfs/scripts/render_pdf.py`
- Web literature/venue check: 2026-09-01

## Frozen reference environment

The A5 candidate binds:

- Darwin ARM64;
- exact CPython 3.12.7 executable identity;
- dependency lock SHA-256 `914c8a6aba4fdea4d811ff7122350e03a869192bd140b0aba2d1f0f7a975e10b`;
- environment SHA-256 `de30817a89c24731ce081e77b3cf6d3a3f39661c3e5449e6ad2e8c964f964acb`;
- wheel SHA-256 `a08d3a80b8ee3e0eacc55a5797ac2ddde3630f02158dc9a7f00a832eabe053cb`;
- runtime-tree SHA-256 `9c4926c8222292f2f67efe37287ff677d403456afb9e5f139fb6752e0235e474`.

The local audit environment does not match the frozen operating system or Python minor version. Exact Host-A/Host-B JUnit records are therefore primary evidence for the full 402-test suite. Candidate-bound logic that was portable to the audit environment was rerun separately.
