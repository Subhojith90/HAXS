# Commands attempted and material outcomes

Date: 2026-09-01

## Archive integrity and extraction

- Recomputed SHA-256 of `HAXS_Stage5C2G_R3_2A_5_Complete_G0_Return.zip`:
  `d9595f46dc919f8d3906b4909cd18833a3659e5f15a04f48ee39787c0f11c9f6`
- Inspected 29 ZIP entries for absolute paths, traversal, duplicate names, encryption flags, and symlink modes:
  PASS, zero unsafe entries.
- Safely extracted into a new audit working directory.
- Recomputed nested protocol SHA-256:
  `d804a203567419f4775fb1d7357cfd9675563ba31068bc10918b9d27f2e1f70f`
- Inspected 776 nested protocol files and 185 directories:
  PASS, zero unsafe ZIP entries.

## Candidate and G0 reconstruction

- Recomputed candidate canonical JSON self-hash:
  `481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932`
  PASS.
- Ran the current immutable-root verifier on a pristine protocol extraction:
  PASS, 775 files, 185 directories, bytecode-closed.
- Recomputed the complete-return manifest and logical return identity:
  `e4c81afb8eb00c60f24572e8e985e5077fda1445a977c05a555fed129ea7d91a`
  PASS.
- Recomputed the two-host comparator from primary Host-A and Host-B records:
  `9745c61a7bbb358472f6d64832af48823686cad1af712e6ddefb3965b6008154`
  PASS; no identity mismatch; physical-host distinction true; forbidden state empty.

## Tests

```bash
python -m compileall -q src scripts scripts_patch tests
```

Result: exit status 0. The host Python emitted an unrelated artifact-tool warm-up warning before the command; compileall itself passed.

```bash
python -m pytest -q tests/stage5c2gR32A5
```

Result: 16 passed, one cache-write warning caused by the read-only extracted evidence permissions.

```bash
python -m pytest -q -p no:cacheprovider <169 candidate-bound targeted nodeids>
```

Result: 169 passed, nine non-fatal warnings.

A fail-fast full 402-nodeid run was attempted, but it exceeded the bounded audit execution window and was interrupted. The exact reference platform is Darwin ARM64, CPython 3.12.7; the audit host was Linux x86-64, CPython 3.13.5.

## Receipt validation

A strict exact-key receipt was generated for candidate:

`481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932`

It was passed to the current finalizer with the submitted protocol and complete G0 return in a temporary external control root. Result:

- status: `LOCKED_G1_ONLY`;
- official attempt limit: 1;
- setup preflight required before attempt: true;
- immutable-root mutation permitted: false.

No official G1 was launched.

## Scientific result extraction

The embedded accepted Stage 5C.2F results archive was safely extracted. The source-generated gate, occupancy, local-window, and paired-effect tables were parsed and independently summarised. No high-cost simulation was rerun.
