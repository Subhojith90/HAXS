# Assumptions and limitations

1. The complete G0 return supplied in the conversation is treated as the source of record. The original downloadable GitHub Actions artifact and full hosted log archive were not separately uploaded at top level.
2. The Host-B evidence was recovered from the immutable Actions artifact after a post-G0 packaging-path failure. The recovery is transparently reported. The current finalizer recomputes host semantics from the supplied primary records, but the hosted artifact should be archived with any public release.
3. The complete 402-test suite was not rerun in the exact Darwin ARM64 CPython 3.12.7 environment. Host JUnit and structured command records support the counts; 16 current-stage and 169 targeted tests were independently rerun.
4. No official G1, transport calibration, untouched exact-surrogate validation, fixed-hole production, Stage 5C3, or Stage 5D scientific execution was performed by the auditor.
5. Mature numerical claims were reconstructed from the embedded accepted Stage 5C.2F result archive. The full high-cost primary simulation was not rerun.
6. The publication judgement is editorial and strategic, not a guarantee of acceptance.
7. Current venue and literature checks are date-stamped 1 September 2026.
8. The report assumes that authorship, institutional approvals, conflicts of interest, and third-party code licensing will be resolved by the human research team before public release or submission.
9. AI-assisted code, analysis, or writing must be disclosed according to the selected venue's current policy and independently verified by the authors.
