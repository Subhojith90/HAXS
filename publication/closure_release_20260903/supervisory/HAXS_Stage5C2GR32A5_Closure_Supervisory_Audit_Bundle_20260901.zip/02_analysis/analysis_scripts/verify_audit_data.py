#!/usr/bin/env python3
"""Validate the bundled audit tables and headline numerical invariants."""

from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "generated_data"

gate = pd.read_csv(DATA / "stage5c2f_gate_table.csv")
assert set(gate["block"]) == {"primary", "confirmation"}
primary = gate.loc[gate["block"] == "primary"].iloc[0]
confirmation = gate.loc[gate["block"] == "confirmation"].iloc[0]
assert primary["mean_effect_db"] < 0
assert primary["hierarchical_ci_high"] < 0
assert confirmation["mean_effect_db"] < 0
assert confirmation["hierarchical_ci_high"] < 0
assert bool(primary["equivalence_pass"])
assert bool(confirmation["equivalence_pass"])

summary = json.loads((ROOT / "audit_summary.json").read_text())
assert summary["current_candidate_sha256"] == "481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932"
assert summary["publication_decision"]["submit_current_physics_manuscript_now"] is False
print("Bundled audit invariants: PASS")
