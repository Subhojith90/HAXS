#!/usr/bin/env python3
"""Regenerate the four audit figures from bundled CSV source data."""

from __future__ import annotations
from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "generated_data"
OUT = ROOT / "generated_figures"
OUT.mkdir(parents=True, exist_ok=True)

gate = pd.read_csv(DATA / "stage5c2f_gate_table.csv")
occ = pd.read_csv(DATA / "stage5c2f_occupancy_effects.csv")
timeline = pd.read_csv(DATA / "closure_timeline.csv")

rng = np.random.default_rng(7)
fig, ax = plt.subplots(figsize=(8.2, 5.2))
for i, block in enumerate(["primary", "confirmation"]):
    vals = occ.loc[occ["block"] == block, "occupancy_mean_effect_db"].to_numpy()
    xs = np.full(len(vals), i, dtype=float) + rng.uniform(-0.09, 0.09, len(vals))
    ax.scatter(xs, vals, alpha=0.8, label=f"{block}: physical occupancies")
    row = gate.loc[gate["block"] == block].iloc[0]
    ax.errorbar(
        [i], [row["mean_effect_db"]],
        yerr=[[row["mean_effect_db"] - row["hierarchical_ci_low"]],
              [row["hierarchical_ci_high"] - row["mean_effect_db"]]],
        fmt="o", capsize=6, linewidth=2.2, markersize=8,
        label=f"{block}: mean and hierarchical 95% interval",
    )
ax.axhline(0, linewidth=1)
ax.set_xticks([0, 1], ["Primary (16 occupancies)", "Frozen confirmation (12 occupancies)"])
ax.set_ylabel("Static-only minus mobile+spin-density effect (dB)")
ax.set_title("Selected 3x3x3 surrogate contrast under the repaired hierarchy")
ax.legend(fontsize=8, loc="lower left")
ax.grid(axis="y", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "selected_geometry_effects.pdf", bbox_inches="tight")
fig.savefig(OUT / "selected_geometry_effects.png", dpi=220, bbox_inches="tight")
plt.close(fig)

rows = []
for _, row in gate.iterrows():
    rows.extend([
        {"block": row["block"], "component": "occupancy", "fraction": row["occupancy_fraction_of_mean_variance"]},
        {"block": row["block"], "component": "hole path", "fraction": row["path_fraction_of_mean_variance"]},
        {"block": row["block"], "component": "phase batch", "fraction": row["phase_fraction_of_mean_variance"]},
    ])
var_df = pd.DataFrame(rows)
pivot = var_df.pivot(index="block", columns="component", values="fraction").loc[["primary", "confirmation"]]
fig, ax = plt.subplots(figsize=(7.8, 4.8))
bottom = np.zeros(len(pivot))
for comp in ["occupancy", "hole path", "phase batch"]:
    values = pivot[comp].to_numpy()
    ax.bar(pivot.index, values, bottom=bottom, label=comp)
    bottom += values
ax.set_ylim(0, 1)
ax.set_ylabel("Fraction of variance of the mean")
ax.set_title("Uncertainty source changes between primary and confirmation blocks")
ax.legend()
ax.grid(axis="y", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "variance_decomposition.pdf", bbox_inches="tight")
fig.savefig(OUT / "variance_decomposition.png", dpi=220, bbox_inches="tight")
plt.close(fig)

fig, ax = plt.subplots(figsize=(7.6, 4.6))
x = np.arange(2)
width = 0.35
ax.bar(x - width / 2, [402, 402], width, label="full suite")
ax.bar(x + width / 2, [169, 169], width, label="targeted suite")
ax.set_xticks(x, ["Host A", "Host B"])
ax.set_ylabel("Passing tests")
ax.set_title("Two-host G0 tested behaviour in the submitted evidence")
ax.legend()
ax.grid(axis="y", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "g0_test_counts.pdf", bbox_inches="tight")
fig.savefig(OUT / "g0_test_counts.png", dpi=220, bbox_inches="tight")
plt.close(fig)

fig, ax = plt.subplots(figsize=(9.2, 5.2))
y = np.arange(len(timeline))
ax.barh(y, timeline["duration"], left=timeline["start"])
ax.set_yticks(y, timeline["period"])
ax.invert_yaxis()
ax.set_xlabel("Calendar day from supervisory decision")
ax.set_title("Hard 28-day publication-closure schedule")
for yi, row in timeline.iterrows():
    ax.text(row["start"] + 0.25, yi, row["task"], va="center", fontsize=8)
ax.set_xlim(0, 28)
ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "closure_timeline.pdf", bbox_inches="tight")
fig.savefig(OUT / "closure_timeline.png", dpi=220, bbox_inches="tight")
plt.close(fig)

print(f"Figures written to {OUT}")
