# Exact next-iteration work order

## Stage

**HAXS-PC1 - Exact-Surrogate Publication Closure**

## Phase 0 - official G1, one attempt only

Use:

- receipt: `SUPERVISOR_AUTHORIZATION_G1_ONLY_STAGE5C2GR32A5.json`
- candidate: `481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932`
- protocol: `d804a203567419f4775fb1d7357cfd9675563ba31068bc10918b9d27f2e1f70f`
- complete G0 logical record: `e4c81afb8eb00c60f24572e8e985e5077fda1445a977c05a555fed129ea7d91a`
- two-host G0: `9745c61a7bbb358472f6d64832af48823686cad1af712e6ddefb3965b6008154`

Command template:

```bash
python -I scripts/finalize_stage5c2gR32A5_authorization.py \
  --receipt SUPERVISOR_AUTHORIZATION_G1_ONLY_STAGE5C2GR32A5.json \
  --protocol-archive HAXS_Stage5C2G_R3_2A_5_Protocol.zip \
  --g0-return HAXS_Stage5C2G_R3_2A_5_Complete_G0_Return.zip \
  --control-root "$HAXS_CONTROL_ROOT" \
  --commit

python -I scripts/launch_stage5c2gR32A5_G1_isolated.py \
  --control-root "$HAXS_CONTROL_ROOT"
```

Stop after terminal G1. Do not retry. Do not run G2.

Return:

- receipt and sidecar;
- `AUTHORIZATION.json`;
- `SETUP.json`;
- terminal `state/G1.json`;
- full G1 artifact directory;
- raw exact and surrogate curves;
- primary and reference semantic decisions;
- execution transcript;
- environment/import attestation;
- artifact manifest and checksum sidecar.

## Phase 1 - M01 transport-only calibration

Prerequisites:

- G1 accepted after separate review;
- frozen M01 development registry;
- frozen M02 untouched registry;
- frozen transport metrics and tolerances;
- squeezing prohibited during calibration.

Required observables:

- hole-density propagation;
- mean-square displacement;
- return probability;
- configuration distance.

Minimum pilot:

- one-hole chains of 5-8 sites;
- 2x3 and 2x4 clusters;
- `t_h/J in {0, 0.25, 0.5, 0.75, 1.0}`;
- at least eight physical initial states per parameter;
- at least 32 stochastic paths and four phase batches per state, or a preregistered precision expansion.

Output:

- exact and surrogate transport curves;
- frozen mobility map with uncertainty;
- calibration-window sensitivity;
- failed runs and attempt ledger;
- immutable M02 holdout registry.

## Phase 2 - M02 untouched validity/failure-boundary gate

Open the untouched registry once.

Primary endpoints:

1. transport error;
2. squeezing-sign agreement;
3. mobile-only versus spin-density-only ranking;
4. full time-profile discrepancy;
5. stability across one- and two-hole cases;
6. predictive boundary performance versus hole-count-only, connectivity-only, and static-dilution baselines.

Pass route:

- all preregistered central criteria pass in a nontrivial domain without squeezing-based retuning.

Failure-boundary route:

- central validity fails, but failures form a held-out, calibrated boundary that beats all trivial baselines.

Stop route:

- no stable valid domain;
- no nontrivial predictive boundary;
- result depends on post-hoc retuning or selected cases.

## Hard dates

- Day 2: G1 complete and returned.
- Day 10: M01 frozen.
- Day 17: M02 decision frozen.
- Day 24: manuscript complete.
- Day 28: submit or close.

## Prohibited work

- No constructive-recovery campaign.
- No broad Stage 5D campaign.
- No new R3.2A authorisation substage after a G1 pass.
- No squeezing-based fit of the mobility map.
- No opening of M02 cases before M01 and analysis code are frozen.
- No exact-mobile-hole, universal no-go, or top-journal claims from the current result.
