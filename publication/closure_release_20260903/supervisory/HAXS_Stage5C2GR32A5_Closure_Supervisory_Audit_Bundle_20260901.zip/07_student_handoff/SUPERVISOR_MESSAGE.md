Subject: HAXS A5 G0 accepted - final publication-closure instruction

Hi Subhojit,

I have completed the Stage 5C.2G-R3.2A.5 review.

The two-host G0 return is accepted for candidate:

481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932

The attached structured receipt authorises G1 only. Run the frozen deterministic G1 exactly once, stop immediately afterwards, and return the complete control root and raw evidence. G2 and all later scopes remain blocked until that review.

I am also imposing a hard project-closure decision. The present result is not sufficient for a defensible mobile-hole mechanism paper. After G1, the project has one final 28-day scientific iteration, HAXS-PC1. It must calibrate stochastic mobility using transport observables only and then test untouched constrained exact/Krylov cases for transport, squeezing sign, component ranking, and time-profile agreement.

By Day 17, we will choose one of three routes: a validated-domain paper, a stable failure-boundary paper, or termination of the physics line. By Day 28, the chosen paper must be submitted or the line must be closed. Do not create another authorisation substage or launch broad Stage 5D compute.

Return the evidence in the exact format specified in the work order.

Regards,
Srinjoy Ganguly
