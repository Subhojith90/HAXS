# Next student response template

## 1. Concise update

State exactly which phase was run and whether its frozen gate passed, failed, or was ambiguous.

## 2. Code diff summary

List modified files and explain why each changed. State whether the candidate, model, metric, or registry identity changed.

## 3. Commands

Provide exact commands, working directory, exit status, start/end time, and resume history.

## 4. Environment and hardware

Provide OS, CPU/GPU, RAM/VRAM, Python, dependency lock, wheel or commit, and numerical-library identity.

## 5. Tests

Provide full and targeted JUnit XML, named-test ledger, stdout, failures, errors, skips, and checksums.

## 6. Raw and processed outputs

Include raw curves, exact outputs, surrogate outputs, failed/incomplete attempts, registries, manifests, and all source-data tables.

## 7. Required tables

- transport calibration;
- calibration-window sensitivity;
- untouched sign agreement;
- component-ranking agreement;
- time-profile errors;
- uncertainty by physical case;
- trivial-baseline comparison;
- final decision table.

## 8. Required figures

- exact versus surrogate transport;
- frozen mobility map and residuals;
- untouched exact versus surrogate squeezing profiles;
- sign/ranking matrix;
- validity or failure-boundary plot;
- selected 3x3x3 case study.

## 9. Known failures

List every failed, incomplete, excluded, or superseded run. Do not hide failed seeds or configurations.

## 10. Interpretation

Separate VERIFIED/RECOMPUTED/REPRODUCED facts from INFERRED explanations and manuscript wording.

## 11. Questions for supervisor

Ask only questions that materially affect the frozen decision, manuscript route, or stop condition.
