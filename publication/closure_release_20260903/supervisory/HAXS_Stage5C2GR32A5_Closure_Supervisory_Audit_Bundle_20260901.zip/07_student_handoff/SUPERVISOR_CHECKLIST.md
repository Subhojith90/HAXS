# Supervisor checklist

## Approve

- [x] Accept A5 two-host G0.
- [x] Issue strict G1-only receipt.
- [ ] Accept G1 only after raw-evidence reconstruction.
- [ ] Approve M01 after G1.
- [ ] Open M02 only after the mobility map, tolerances, and holdout registry are frozen.
- [ ] Select manuscript route on Day 17.
- [ ] Submit or stop on Day 28.

## Reject

- [x] Current as-is mobile-hole physics manuscript.
- [x] PRL or PRX Quantum submission now.
- [x] New constructive-recovery search.
- [x] Broad Stage 5D compute.
- [x] Further protocol-stage proliferation.
- [x] Exact lithium mobile-hole wording.
- [x] Public software-paper claim before release cleanup.

## Claims allowed

- A5 G0 and tested-behaviour closure.
- One selected-geometry stochastic-surrogate negative contrast.
- G1-only authorisation.

## Claims forbidden

- Microscopic mobile-hole mechanism.
- Causality.
- Universal boundary/no-go.
- Experimental quantitative prediction.
- Cross-dimensional generalisation.
- Publication readiness.
