# HAXS Stage 5C.2G-R3.2A.5 supervisory audit bundle

## Headline decision

- A5 two-host G0: **accepted**.
- Strict G1-only receipt: **issued**.
- Current as-is mobile-hole physics paper: **not defensible**.
- Final approved scientific iteration: **HAXS-PC1 - Exact-Surrogate Publication Closure**.
- Hard closure deadline: **28 days from the supervisory decision**.

## Main files

- `01_report/supervisory_report.pdf`: compiled report.
- `01_report/overleaf_project.zip`: self-contained LaTeX project.
- `02_analysis/`: scripts and machine-readable analysis data.
- `03_figures/`: publication and diagnostic figures plus source data.
- `04_tables/`: report tables in CSV/JSON form.
- `05_audit_ledgers/`: evidence, claim, risk, publication, and novelty ledgers.
- `06_reproducibility/`: commands, environment, limitations, compile log, and PDF renders.
- `07_student_handoff/`: receipt, work order, supervisor message, checklist, and response template.

## Recompile

Extract `01_report/overleaf_project.zip` and run:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The project uses pdfLaTeX and Biber through latexmk.

## Scope

The bundle does not contain the full 416 MB submitted G0 archive. It records the exact file identities and audit results and refers to the original conversation uploads as evidence. Small generated source-data tables needed to reproduce the audit figures are included.

## Receipt

Receipt ID: `f8035d48-a73c-49b1-bf60-872983b24d62`  
Receipt SHA-256: `16b1c098c6201a587e1929eae50999d5eb44fb923cecc41694a01a25562429db`  
Scope: `G1_ONLY`
