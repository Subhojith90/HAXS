# Stage 5C.2G-R3.2A.5 official G1 terminal return

## Disposition

**TERMINAL FAILED — no rerun performed; no G2 or downstream execution performed.**

## Frozen identities

- Candidate SHA-256: `481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932`
- Protocol archive SHA-256: `d804a203567419f4775fb1d7357cfd9675563ba31068bc10918b9d27f2e1f70f`
- Complete G0 logical return SHA-256: `e4c81afb8eb00c60f24572e8e985e5077fda1445a977c05a555fed129ea7d91a`
- Two-host G0 SHA-256: `9745c61a7bbb358472f6d64832af48823686cad1af712e6ddefb3965b6008154`
- Receipt ID: `f8035d48-a73c-49b1-bf60-872983b24d62`
- Receipt SHA-256: `16b1c098c6201a587e1929eae50999d5eb44fb923cecc41694a01a25562429db`
- Attempt ID: `52e6f14b27a2474ba6db70755825d893`

## What passed before reservation

- Strict receipt sidecar verification.
- Candidate, protocol, complete-G0-return, and two-host-G0 identity validation.
- Atomic `LOCKED_G1_ONLY` authorization commit.
- Immutable-root exact-membership verification.
- Candidate-bound CPython 3.12.7 environment verification.
- Installed-wheel tree verification.
- Frozen launcher, runner, G1 configuration, G1 plan, and unit-registry verification.

The setup record was written before the scientific attempt was reserved, and the terminal state records sequence `1` and status `FAILED`.

## Failure and evidentiary limitation

The isolated child runner returned exit status `1`. The A5 launcher then terminalized the attempt correctly but replaced the child runner's captured stdout with the wrapper exception:

```text
RuntimeError('official runner failed with exit status 1')
EXIT_STATUS=1
```

The launcher used a temporary scientific-output directory and deleted it on context exit. Consequently, the preserved terminal return contains neither the child traceback nor partial scientific files. The present evidence cannot determine whether the child failure was:

1. a deterministic G1 predicate failure; or
2. a runtime/import/serialization defect inside the child process.

No scientific conclusion should be drawn from this terminal record.

## Narrow development repair completed after terminalization

The development launcher now carries the child transcript and any existing partial scientific-output directory into failed terminal evidence. A regression test verifies both properties, and the focused A5 lifecycle suite passes (`17 passed`). This repair has not been used to rerun G1 and is not represented as the accepted A5 candidate.

## Requested supervisory disposition

Please classify this as the single permitted packaging/evidence-capture repair review. If a replacement attempt is authorized, it requires a newly frozen candidate and a new exact-key G1-only receipt. Otherwise, the project will retain this attempt as terminal and proceed only under the publication-closure route you authorize.

## Deliverable

- `HAXS_Stage5C2G_R3_2A_5_Official_G1_Return.zip`
- SHA-256: `f45296eeae73101b59bcf22197e8830a9b0eb650fe6b2f58c3dd02826bf1594e`

