Subject: HAXS R3.2A.5 — official G1 terminal failure and evidence-capture repair review

Dear Srinjoy,

I ran the authorized Stage 5C.2G-R3.2A.5 deterministic G1 exactly once using receipt `f8035d48-a73c-49b1-bf60-872983b24d62`, candidate `481ca1905bedc68d6ac3eb36ac61b80356d4e32cf8847b3e927f081201240932`, and protocol `d804a203567419f4775fb1d7357cfd9675563ba31068bc10918b9d27f2e1f70f`.

Authorization, immutable-root verification, environment verification, wheel installation, and execution-contract verification all passed. The isolated child runner then returned exit status 1, and the attempt terminalized as FAILED with attempt ID `52e6f14b27a2474ba6db70755825d893`. I stopped immediately. I did not rerun G1 and did not run G2 or any downstream stage.

The terminal evidence exposed a narrow observability defect: the launcher preserved only its wrapper exception and deleted the temporary child scientific-output directory. It therefore did not retain the child traceback or partial scientific files, so the current return cannot distinguish a scientific predicate failure from a child runtime defect.

I have preserved the complete terminal control root and implemented a development-only repair that retains child stdout and partial scientific output on failure. The focused lifecycle suite passes 17 tests. I have not used the repair to execute G1.

Attached are:

1. `HAXS_Stage5C2G_R3_2A_5_Official_G1_Return.zip`
2. `HAXS_Stage5C2G_R3_2A_5_Official_G1_Return_SHA256.txt`
3. `G1_FAILURE_RETURN_NOTE.md`

Please review this under the single permitted packaging/evidence-capture repair clause and advise whether to freeze a replacement candidate and issue a new G1-only receipt. The scientific manuscript has been started using only the already accepted Stage 5C.2F surrogate result; no claim has been made from this opaque G1 failure.

Best regards,
Subhojit
